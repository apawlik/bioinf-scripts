###### MacroPopGen Database ######
#Code by E.R. Lawrence and J-M. Matte

########## Figure 1 ########## 
data <- read.csv(file = "MacroPopGen_Database_final.csv")

data <- data[which(data$TaxaClass != "Brackish" & data$TaxaClass != "Catadromous"),] #only plot Fw and anadromous fish
data.clean <- data
#### Ho ####
data <- data[!(is.na(data$Ho)),]
ho <- aggregate(data$Ho, list(data$G_s, data$Country),  function(x) 100*sd(x)/mean(x))
ho <- ho[!(is.na(ho$x)),]
colnames(ho) <- c("G_s", "Country", "CV")
ho$Continent = factor(NA, levels = levels(data$Continent))
ho$Taxa = factor(NA, levels = levels(data$TaxaClass))
ho$Reference = factor(NA, levels = levels(data$RefID))
ho$Family = factor(NA, levels = levels(data$Family))
for(x in 1:nrow(ho)){
        junk <- data[which(data$Country == ho$Country[x] & data$G_s == ho$G_s[x]),]
        ho$Continent[x] <- junk$Continent[1]
        ho$Taxa[x] <- junk$TaxaClass[1]
        ho$Reference[x] <- junk$RefID[1]
        ho$Family[x] <- junk$Family[1]
}
library(lme4)
#Determine if Continent or Taxa more strongly influences CV of Ho
ho <- ho[which(ho$CV != 0),]
m0 <- glmer(data = ho, CV ~ 1 + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
m1 <- glmer(data = ho, CV ~ Continent + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
m2 <- glmer(data = ho, CV ~ Taxa + (1|Reference) , family = "Gamma", optimizer = "Nelder_Mead")
m3 <- glmer(data = ho, CV ~ Continent + Taxa + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
#failed to converge:
ss <- getME(m3,c("theta","fixef"))
m3b <- update(m3,start=ss,control=glmerControl(optimizer="bobyqa",
                                               optCtrl=list(maxfun=2e6))) #converges

m4 <- glmer(data = ho, CV ~ Taxa * Continent + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
#failed to converge:
ss <- getME(m4,c("theta","fixef"))
m4b <- update(m4,start=ss,control=glmerControl(optimizer="bobyqa",
                                               optCtrl=list(maxfun=2e6))) #converges

a <- anova(m0, m1,m2,m3b,m4b)
row.names(a)[which(a$AIC == min(a$AIC))]

#m2 selected = Taxa

summary(m2)

library(emmeans)
m <- emmeans(m2, specs = ~Taxa, what = "response")
s <- data.frame(summary(m, type = "response"))

#plot Ho CV across taxa
library(ggplot2)
cv_ho_taxa <- ggplot(s, aes(x=Taxa, y=response)) +
        geom_errorbar(width=.1, aes(ymin=response-SE, ymax=response + SE)) +
        theme(axis.text.x = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              axis.title.x = element_text(size=20,angle=0,hjust=.5,vjust=.5)) +
        geom_point(shape=21, size=5, fill="white") + ylab("Ho: Coefficient of Variation")



#Ho glmmTMB for plotting mean Ho across taxa and continent
data <- data.clean
data1 <- data[which(data$Ho > 0 & data$Ho < 1),]

library(glmmTMB)

model0 <- glmmTMB(Ho ~ 1+
                          (1|RefID) + (1|Species) + (1|Genus) + (1|Family),
                  family=beta_family(), data = data1)

model1 <- glmmTMB(Ho ~ TaxaClass+
                          (1|RefID) + (1|Species) + (1|Genus) + (1|Family),
                  family=beta_family(), data = data1)

recover.data.glmmTMB <- function(object, ...) {
        fcall <- getCall(object)
        recover.data(fcall,delete.response(terms(object)),
                     attr(model.frame(object),"na.action"), ...)}
lsm.basis.glmmTMB <- function (object, trms, xlev, grid, vcov.,
                               mode = "asymptotic", component="cond", ...) {
        if (mode != "asymptotic") stop("only asymptotic mode is available")
        if (component != "cond") stop("only tested for conditional component")
        if (missing(vcov.)) 
                V <- as.matrix(vcov(object)[[component]])
        else V <- as.matrix(.my.vcov(object, vcov.))
        dfargs = misc = list()
        if (mode == "asymptotic") {
                dffun = function(k, dfargs) NA
        }
        ## use this? misc = .std.link.labels(family(object), misc)
        contrasts = attr(model.matrix(object), "contrasts")
        m = model.frame(trms, grid, na.action = na.pass, xlev = xlev)
        X = model.matrix(trms, m, contrasts.arg = contrasts)
        bhat = fixef(object)[[component]]
        if (length(bhat) < ncol(X)) {
                kept = match(names(bhat), dimnames(X)[[2]])
                bhat = NA * X[1, ]
                bhat[kept] = fixef(object)[[component]]
                modmat = model.matrix(trms, model.frame(object), contrasts.arg = contrasts)
                nbasis = estimability::nonest.basis(modmat)
        }
        else nbasis = estimability::all.estble
        list(X = X, bhat = bhat, nbasis = nbasis, V = V, dffun = dffun, 
             dfargs = dfargs, misc = misc)
}


library(emmeans)
result <- emmeans(model1, specs =~ TaxaClass, what = "response")
summary(result, type = "response")


library(RVAideMemoire)
result.bt <- back.emmeans(result, transform = c("logit"), base = exp(1),) #back transform emmeans values
aggregate(data1$Ho, list(data1$TaxaClass), mean) #Just to check it lines up
library(ggplot2)
mean_ho_taxa <- ggplot(result.bt, aes(x=TaxaClass, y=EMMean)) +
        scale_y_continuous(limits=c(0.52, 0.68)) +
        geom_errorbar(width=.1, aes(ymin=SE.inf, ymax=SE.sup)) +
        theme(axis.text.x = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              axis.title.x = element_text(size=20,angle=0,hjust=.5,vjust=.5)) +
        geom_point(shape=21, size=5, fill="white") + ylab("Mean Ho")


#data1$Continent <- relevel(data1$Continent, "SAm")

model2 <- glmmTMB(Ho ~ Continent +
                          (1|RefID) + (1|Species) + (1|Genus) + (1|Family),
                  family=beta_family(), data = data1)

library(emmeans)
result <- emmeans(model2, specs =~ Continent, what = "response")
summary(result, type = "response")


library(RVAideMemoire)
result.bt <- back.emmeans(result, transform = c("logit"), base = exp(1),)
aggregate(data1$Ho, list(data1$Continent), mean)
library(ggplot2)
mean_ho_cont <- ggplot(result.bt, aes(x=Continent, y=EMMean)) +
        scale_y_continuous(limits=c(0.52, 0.68)) +
        geom_errorbar(width=.1, aes(ymin=SE.inf, ymax=SE.sup)) +
        theme(axis.text.x = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              axis.title.x = element_text(size=20,angle=0,hjust=.5,vjust=.5)) +
        geom_point(shape=22, size=5, fill="white") + ylab("Mean Ho")


#### MNA ####
data <- data.clean
data <- data[!(is.na(data$MNA)),]
mna <- aggregate(data$MNA, list(data$G_s, data$Country),  function(x) 100*sd(x)/mean(x))
mna <- mna[!(is.na(mna$x)),]
colnames(mna) <- c("G_s", "Country", "CV")
mna$Continent = factor(NA, levels = levels(data$Continent))
mna$Taxa = factor(NA, levels = levels(data$TaxaClass))
mna$Reference = factor(NA, levels = levels(data$RefID))
mna$Family = factor(NA, levels = levels(data$Family))
for(x in 1:nrow(mna)){
        junk <- data[which(data$Country == mna$Country[x] & data$G_s == mna$G_s[x]),]
        mna$Continent[x] <- junk$Continent[1]
        mna$Taxa[x] <- junk$TaxaClass[1]
        mna$Reference[x] <- junk$RefID[1]
        mna$Family[x] <- junk$Family[1]
}
hist(mna$CV, breaks = 75)
library(lme4)
mna <- mna[which(mna$CV != 0),]
#Determine if Continent or Taxa or null best for MNA
m0 <- glmer(data = mna, CV ~ 1 + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
m1 <- glmer(data = mna, CV ~ Continent + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
m2 <- glmer(data = mna, CV ~ Taxa + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
ss <- getME(m2,c("theta","fixef"))
m2b <- update(m2,start=ss,control=glmerControl(optimizer="bobyqa",
                                               optCtrl=list(maxfun=2e6)))


m3 <- glmer(data = mna, CV ~ Continent + Taxa + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
ss <- getME(m3,c("theta","fixef"))
m3b <- update(m3,start=ss,control=glmerControl(optimizer="bobyqa",
                                               optCtrl=list(maxfun=2e6)))

m4 <- glmer(data = mna, CV ~ Taxa * Continent + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
ss <- getME(m4,c("theta","fixef"))
m4b <- update(m4,start=ss,control=glmerControl(optimizer="bobyqa",
                                               optCtrl=list(maxfun=2e6)))

anova(m0, m1,m2b,m3b,m4b)
#M0 selected = null model

#
library(emmeans)
m <- emmeans(m2, specs = ~Taxa, what = "response")
s <- data.frame(summary(m, type = "response"))

library(ggplot2)
cv_mna_taxa <- ggplot(s, aes(x=Taxa, y=response)) +
        geom_errorbar(width=.1, aes(ymin=response-SE, ymax=response + SE)) +
        theme(axis.text.x = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              axis.title.x = element_text(size=20,angle=0,hjust=.5,vjust=.5)) +
        geom_point(shape=21, size=5, fill="white") + ylab("MNA: Coefficient of Variation")


#Gamma distributed model for means of MNA across taxa and continent
data1   <- data[which(data$MNA != 0),]
m2 <- glmer(data = data1, MNA ~ TaxaClass + (1|RefID), family = "Gamma", optimizer = "Nelder_Mead")
#failed to converge
ss <- getME(m2,c("theta","fixef"))
m2b <- update(m2,start=ss,control=glmerControl(optimizer="bobyqa",
                                               optCtrl=list(maxfun=2e6))) #converges


library(emmeans)
m <- emmeans(m2, specs = ~TaxaClass, what = "response")
s <- data.frame(summary(m, type = "response"))

library(ggplot2)
mean_mna_taxa <- ggplot(s, aes(x=TaxaClass, y=response)) +
        scale_y_continuous(limits=c(3, 9)) +
        geom_errorbar(width=.1, aes(ymin=response-SE, ymax=response + SE)) +
        theme(axis.text.x = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              axis.title.x = element_text(size=20,angle=0,hjust=.5,vjust=.5)) +
        geom_point(shape=21, size=5, fill="white") + ylab("Mean MNA")

#plot for mean MNA across continents
data <- data.clean
data<-subset(data, !is.na(MNA))
data<-subset(data, !MNA==0)

#data$Continent <- relevel(data$Continent, "SAm")
m2<-glmer(MNA ~ Continent + (1|RefID) + (1|Family) + (1|Genus), 
          control = glmerControl(optimizer = "Nelder_Mead"), 
          family=Gamma, data=data)
summary(m2)
mm <- emmeans(m2, specs = ~Continent, what = "response")
s2 <- data.frame(summary(mm, type = "response"))

library(ggplot2)
mean_mna_cont<-ggplot(s2, aes(x=Continent, y=response)) +
        geom_errorbar(width=.1, aes(ymin=response-SE, ymax=response + SE)) +
        scale_y_continuous(limits=c(3, 9)) +
        theme(axis.text.x = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              axis.title.x = element_text(size=20,angle=0,hjust=.5,vjust=.5)) +
        geom_point(shape=22, size=5, fill="white") + ylab("Mean MNA")


#### FST ####
data <- data.clean
data <- data[!(is.na(data$FST)),]
FST <- aggregate(data$FST, list(data$G_s, data$Country),  function(x) 100*sd(x)/mean(x))
FST <- FST[!(is.na(FST$x)),]
colnames(FST) <- c("G_s", "Country", "CV")
FST$Continent = factor(NA, levels = levels(data$Continent))
FST$Taxa = factor(NA, levels = levels(data$TaxaClass))
FST$Reference = factor(NA, levels = levels(data$RefID))
FST$Family = factor(NA, levels = levels(data$Family))
for(x in 1:nrow(FST)){
        junk <- data[which(data$Country == FST$Country[x] & data$G_s == FST$G_s[x]),]
        FST$Continent[x] <- junk$Continent[1]
        FST$Taxa[x] <- junk$TaxaClass[1]
        FST$Reference[x] <- junk$RefID[1]
        FST$Family[x] <- junk$Family[1]
}
library(lme4)
FST <- FST[which(FST$CV != 0),]
#FST$Continent <- relevel(FST$Continent, "NAm")
m0 <- glmer(data = FST, CV ~ 1 + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
m1 <- glmer(data = FST, CV ~ Continent + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
m2 <- glmer(data = FST, CV ~ Taxa + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
#failed converge
ss <- getME(m2,c("theta","fixef"))
m2b <- update(m2,start=ss,control=glmerControl(optimizer="bobyqa",
                                               optCtrl=list(maxfun=2e6))) #converges


m3 <- glmer(data = FST, CV ~ Continent + Taxa + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
#failed converge
ss <- getME(m3,c("theta","fixef"))
m3b <- update(m3,start=ss,control=glmerControl(optimizer="bobyqa",
                                               optCtrl=list(maxfun=2e6))) #converges

m4 <- glmer(data = FST, CV ~ Taxa * Continent + (1|Reference), family = "Gamma", optimizer = "Nelder_Mead")
#failed converge
ss <- getME(m4,c("theta","fixef"))
m4b <- update(m4,start=ss,control=glmerControl(optimizer="bobyqa",
                                               optCtrl=list(maxfun=2e8))) #converges

anova(m0, m1,m2b,m3b)

#m1 selected = continent
summary(m1)

library(emmeans)
m <- emmeans(m1, specs = ~Continent, what = "response")
s <- data.frame(summary(m, type = "response"))

library(ggplot2)
cv_fst_cont <- ggplot(s, aes(x=Continent, y=response)) +
        geom_errorbar(width=.1, aes(ymin=response-SE, ymax=response + SE)) +
        theme(axis.text.x = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              axis.title.x = element_text(size=20,angle=0,hjust=.5,vjust=.5)) +
        geom_point(shape=22, size=5, fill="white") + ylab("FST: Coefficient of Variation")

#mean FST glmmTMB for taxa and continent
data <- data.clean
data1 <- data[which(data$FST > 0),]
 
library(glmmTMB)
#data1$TaxaClass <- relevel(data1$TaxaClass, "Aves")

model0 <- glmmTMB(FST ~ 1+
                          (1|RefID) + (1|Species) + (1|Genus) + (1|Family),
                  family=beta_family(), data = data1)

model1 <- glmmTMB(FST ~ TaxaClass+
                          (1|RefID) + (1|Species) + (1|Genus) + (1|Family),
                  family=beta_family(), data = data1)

recover.data.glmmTMB <- function(object, ...) {
        fcall <- getCall(object)
        recover.data(fcall,delete.response(terms(object)),
                     attr(model.frame(object),"na.action"), ...)}
lsm.basis.glmmTMB <- function (object, trms, xlev, grid, vcov.,
                               mode = "asymptotic", component="cond", ...) {
        if (mode != "asymptotic") stop("only asymptotic mode is available")
        if (component != "cond") stop("only tested for conditional component")
        if (missing(vcov.)) 
                V <- as.matrix(vcov(object)[[component]])
        else V <- as.matrix(.my.vcov(object, vcov.))
        dfargs = misc = list()
        if (mode == "asymptotic") {
                dffun = function(k, dfargs) NA
        }
        ## use this? misc = .std.link.labels(family(object), misc)
        contrasts = attr(model.matrix(object), "contrasts")
        m = model.frame(trms, grid, na.action = na.pass, xlev = xlev)
        X = model.matrix(trms, m, contrasts.arg = contrasts)
        bhat = fixef(object)[[component]]
        if (length(bhat) < ncol(X)) {
                kept = match(names(bhat), dimnames(X)[[2]])
                bhat = NA * X[1, ]
                bhat[kept] = fixef(object)[[component]]
                modmat = model.matrix(trms, model.frame(object), contrasts.arg = contrasts)
                nbasis = estimability::nonest.basis(modmat)
        }
        else nbasis = estimability::all.estble
        list(X = X, bhat = bhat, nbasis = nbasis, V = V, dffun = dffun, 
             dfargs = dfargs, misc = misc)
}


library(emmeans)
result <- emmeans(model1, specs =~ TaxaClass, what = "response")
summary(result, type = "response")


library(RVAideMemoire)
result.bt <- back.emmeans(result, transform = c("logit"), base = exp(1),) #back transform emmeans values
aggregate(data1$FST, list(data1$TaxaClass), mean) #Just to check it lines up
library(ggplot2)
mean_fst_taxa <- ggplot(result.bt, aes(x=TaxaClass, y=EMMean)) +
        scale_y_continuous(limits=c(0.03, 0.15)) +
        geom_errorbar(width=.1, aes(ymin=SE.inf, ymax=SE.sup)) +
        theme(axis.text.x = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              axis.title.x = element_text(size=20,angle=0,hjust=.5,vjust=.5)) +
        geom_point(shape=21, size=5, fill="white") + ylab("FST")



model2 <- glmmTMB(FST ~ Continent+
                          (1|RefID) + (1|Species) + (1|Genus) + (1|Family),
                  family=beta_family(), data = data1)

library(emmeans)
result <- emmeans(model2, specs =~ Continent, what = "response")
summary(result, type = "response")


library(RVAideMemoire)
result.bt <- back.emmeans(result, transform = c("logit"), base = exp(1),)
aggregate(data1$FST, list(data1$Continent), mean)
library(ggplot2)
mean_fst_cont <- ggplot(result.bt, aes(x=Continent, y=EMMean)) +
        scale_y_continuous(limits=c(0.03, 0.15)) +
        geom_errorbar(width=.1, aes(ymin=SE.inf, ymax=SE.sup)) +
        theme(axis.text.x = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              axis.title.x = element_text(size=20,angle=0,hjust=.5,vjust=.5)) +
        geom_point(shape=22, size=5, fill="white") + ylab("FST")


#### all figures together ####
library(lme4)
library(emmeans)
#make blank plot for CV and MNA
cv_mna_blank<-ggplot(data, aes(x = TaxaClass, y = MNA)) + geom_blank() +
        scale_y_continuous(limits=c(3, 8.5)) +
        theme(axis.text.x = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              axis.title.x = element_text(size=20,angle=0,hjust=.5,vjust=.5)) +
        ylab("MNA: Coefficient of Variation")
#blanked out later in figure making process


library(gridExtra) #arrange all plots together
grid.arrange(nrow=3, ncol=3, cv_fst_cont, cv_ho_taxa, cv_mna_blank, 
             mean_fst_taxa, mean_ho_taxa, mean_mna_taxa,  
             mean_fst_cont, mean_ho_cont, mean_mna_cont)

########## Figure 2 ########## 
fdat<-read.csv("MacroPopGen_Database_final.csv")
fdat <- fdat[!(is.na(fdat$Ho)),]
fdat <- fdat[which(fdat$TaxaClass != "Brackish" & fdat$TaxaClass != "Catadromous"),]
cols<-c("darkgreen", "navyblue", "purple", "blue",  "orange", "olivedrab3")
summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE,
                      conf.interval=.95, .drop=TRUE) {
        library(plyr)
        
        # New version of length which can handle NA's: if na.rm==T, don't count them
        length2 <- function (x, na.rm=FALSE) {
                if (na.rm) sum(!is.na(x))
                else       length(x)
        }
        
        # This does the summary. For each group's data frame, return a vector with
        # N, mean, and sd
        datac <- ddply(data, groupvars, .drop=.drop,
                       .fun = function(xx, col) {
                               c(N    = length2(xx[[col]], na.rm=na.rm),
                                 mean = mean   (xx[[col]], na.rm=na.rm),
                                 sd   = sd     (xx[[col]], na.rm=na.rm)
                               )
                       },
                       measurevar
        )
        
        # Rename the "mean" column    
        datac <- rename(datac, c("mean" = measurevar))
        
        datac$se <- datac$sd / sqrt(datac$N)  # Calculate standard error of the mean
        
        # Confidence interval multiplier for standard error
        # Calculate t-statistic for confidence interval: 
        # e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
        ciMult <- qt(conf.interval/2 + .5, datac$N-1)
        datac$ci <- datac$se * ciMult
        
        return(datac)
}

pen<-summarySE(fdat,measurevar="Ho", groupvars=c("Family", "TaxaClass"),na.rm = T)
pen2<-summarySE(fdat,measurevar="MNA", groupvars=c("Family", "TaxaClass"),na.rm = T)
pen3<-summarySE(fdat,measurevar="Ho", groupvars=c("Genus", "TaxaClass"),na.rm = T)
pen4<-summarySE(fdat,measurevar="MNA", groupvars=c("Genus", "TaxaClass"),na.rm = T)
pen5<-summarySE(fdat,measurevar="FST", groupvars=c("Family", "TaxaClass"),na.rm = T)
pen6<-summarySE(fdat,measurevar="FST", groupvars=c("Genus", "TaxaClass"),na.rm = T)

p1<-ggplot(pen, aes(x=Family, y=Ho, colour=TaxaClass)) + 
        ggtitle("Family") + 
        theme(plot.title = element_text(size=20)) +
        geom_errorbar(aes(ymin=Ho-se, ymax=Ho+se), width=.1, size=1.5) +
        geom_point(size=4) + labs(x = "", y = "Ho") +
        scale_colour_manual(values=cols) +
        theme(axis.text.x = element_text(size=0,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              legend.position="none", panel.background = element_rect(fill = "gray100", colour = "gray100",
                                                                      size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid', colour = "gray99"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid', colour = "gray99"),
              panel.border = element_rect(fill=NA, colour="black",size = 0.5, linetype = "solid"))
p2<-ggplot(pen2, aes(x=Family, y=MNA, colour=TaxaClass)) + 
        geom_errorbar(aes(ymin=MNA-se, ymax=MNA+se), width=.1, size=1.5) +
        geom_point(size=4) + labs(x = "", y = "MNA") +
        scale_colour_manual(values=cols) +
        theme(axis.text.x = element_text(size=0,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              legend.position="none", panel.background = element_rect(fill = "gray100", colour = "gray100",
                                                                      size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid', colour = "gray99"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid', colour = "gray99"),
              panel.border = element_rect(fill=NA, colour="black",size = 0.5, linetype = "solid"))
p3<-ggplot(pen3, aes(x=Genus, y=Ho, colour=TaxaClass)) + 
        ggtitle("Genus") + 
        theme(plot.title = element_text(size=20)) +
        geom_errorbar(aes(ymin=Ho-se, ymax=Ho+se), width=.1, size=1.5) +
        geom_point(size=4) + labs(x = "", y = "Ho") +
        scale_colour_manual(values=cols) +
        theme(axis.text.x = element_text(size=0,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              legend.position="none", panel.background = element_rect(fill = "gray100", colour = "gray100",
                                                                      size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid', colour = "gray99"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid', colour = "gray99"),
              panel.border = element_rect(fill=NA, colour="black",size = 0.5, linetype = "solid"))
p4<-ggplot(pen4, aes(x=Genus, y=MNA, colour=TaxaClass)) + 
        geom_errorbar(aes(ymin=MNA-se, ymax=MNA+se), width=.1, size=1.5) +
        geom_point(size=4) + labs(x = "", y = "MNA") +
        scale_colour_manual(values=cols) +
        theme(axis.text.x = element_text(size=0,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              legend.position="none", panel.background = element_rect(fill = "gray100", colour = "gray100",
                                                                      size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid', colour = "gray99"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid', colour = "gray99"),
              panel.border = element_rect(fill=NA, colour="black",size = 0.5, linetype = "solid"))
p5<-ggplot(pen5, aes(x=Family, y=FST, colour=TaxaClass)) + 
        geom_errorbar(aes(ymin=FST-se, ymax=FST+se), width=.1, size=1.5) +
        geom_point(size=4) + labs(x = "", y = "FST") +
        scale_colour_manual(values=cols) +
        theme(axis.text.x = element_text(size=0,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              legend.position="none", panel.background = element_rect(fill = "gray100", colour = "gray100",
                                                                      size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid', colour = "gray99"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid', colour = "gray99"),
              panel.border = element_rect(fill=NA, colour="black",size = 0.5, linetype = "solid"))
p6<-ggplot(pen6, aes(x=Genus, y=FST, colour=TaxaClass)) + 
        geom_errorbar(aes(ymin=FST-se, ymax=FST+se), width=.1, size=1.5) +
        geom_point(size=4) + labs(x = "", y = "FST") +
        scale_colour_manual(values=cols) +
        theme(axis.text.x = element_text(size=0,angle=0, hjust=.5,vjust=.5),
              axis.text.y = element_text(size=20,angle=0, hjust=.5,vjust=.5),
              axis.title.y = element_text(size=20,angle=90,hjust=.5,vjust=.5),
              legend.position="none", panel.background = element_rect(fill = "gray100", colour = "gray100",
                                                                      size = 0.5, linetype = "solid"),
              panel.grid.major = element_line(size = 0.5, linetype = 'solid', colour = "gray99"), 
              panel.grid.minor = element_line(size = 0.25, linetype = 'solid', colour = "gray99"),
              panel.border = element_rect(fill=NA, colour="black",size = 0.5, linetype = "solid"))

library(gridExtra)
grid.arrange(p1, p3, p2, p4, p5, p6, ncol=2, nrow=3)


########## Figure 3 ########## 
fdat<-read.csv("MacroPopGen_Database_final.csv")
par(mfrow=c(6,3), mar=c(2,3,2,0.5))

plot(fdat$Year,fdat$Ho, xlab="Year",main="Observed Heterozygosity", ylab="All", pch=19, cex=1.5,
     col="grey", xlim = c(1990,2017), ylim = c(0,1), cex.axis=2, cex.lab=2, cex.main=2)
abline(lm(fdat$Ho~fdat$Year), lwd=2)
plot(fdat$Year,fdat$MNA, xlab="Year",main="Mean Number of Alleles", ylab="", pch=19,
     col="grey", xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, cex=1.5)
abline(lm(fdat$MNA~fdat$Year), lwd=2)
plot(fdat$Year,fdat$Msats, xlab="Year",main="Microsatellite Loci", ylab="", pch=19,
     col="grey", xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, cex=1.5)
abline(lm(fdat$Msats~fdat$Year), lwd=2)

plot(fdat$Year[which(fdat$TaxaClass == "Amphibia")],fdat$Ho[which(fdat$TaxaClass == "Amphibia")],xlab="Year",main="",
     col="darkgreen", xlim = c(1990,2017), ylim = c(0,1), cex.axis=2, cex.lab=2, cex.main=2, ylab="Amphibians", pch=19, cex=1.5)
abline(lm(fdat$Ho[which(fdat$TaxaClass == "Amphibia")]~fdat$Year[which(fdat$TaxaClass == "Amphibia")]), lwd=2)
plot(fdat$Year[which(fdat$TaxaClass == "Amphibia")],fdat$MNA[which(fdat$TaxaClass == "Amphibia")],xlab="Year",main="", pch=19,
     col="darkgreen", xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, ylab="", cex=1.5)
plot(fdat$Year[which(fdat$TaxaClass == "Amphibia")],fdat$Msats[which(fdat$TaxaClass == "Amphibia")],xlab="Year",main="", pch=19,
     col="darkgreen", xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, ylab="", cex=1.5)
abline(lm(fdat$MNA[which(fdat$TaxaClass == "Amphibia")]~fdat$Year[which(fdat$TaxaClass == "Amphibia")]), lwd=2)

plot(fdat$Year[which(fdat$TaxaClass == "Aves")], fdat$Ho[which(fdat$TaxaClass == "Aves")], xlab="Year",main="",
     col="purple",xlim = c(1990,2017), ylim = c(0,1), cex.axis=2, cex.lab=2, cex.main=2, ylab="Birds", pch=19, cex=1.5)
plot(fdat$Year[which(fdat$TaxaClass == "Aves")], fdat$MNA[which(fdat$TaxaClass == "Aves")], xlab="Year",main="", pch=19,
     col="purple",xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, ylab="", cex=1.5)
abline(lm(fdat$MNA[which(fdat$TaxaClass == "Aves")]~fdat$Year[which(fdat$TaxaClass == "Aves")]), lwd=2)
plot(fdat$Year[which(fdat$TaxaClass == "Aves")], fdat$Msats[which(fdat$TaxaClass == "Aves")], xlab="Year",main="", pch=19,
     col="purple",xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, ylab="", cex=1.5)
abline(lm(fdat$Msats[which(fdat$TaxaClass == "Aves")]~fdat$Year[which(fdat$TaxaClass == "Aves")]), lwd=2)


plot(fdat$Year[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")],
     fdat$Ho[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")],xlab="Year",main="",
     col="blue",xlim = c(1990,2017), ylim = c(0,1), cex.axis=2, cex.lab=2, cex.main=2, ylab="Fish", pch=19, cex=1.5)
abline(lm(fdat$Ho[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")]~fdat$Year[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")]), lwd=2)
plot(fdat$Year[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")],
     fdat$MNA[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")],xlab="Year",main="", pch=19,
     col="blue",xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, ylab="", cex=1.5)
abline(lm(fdat$MNA[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")]~fdat$Year[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")]), lwd=2)
plot(fdat$Year[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")],
     fdat$Msats[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")],xlab="Year",main="", pch=19,
     col="blue",xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, ylab="", cex=1.5)
abline(lm(fdat$MNA[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")]~fdat$Year[which(fdat$TaxaClass == "Brackish" | fdat$TaxaClass == "Anadromous" | fdat$TaxaClass == "Freshwater" | fdat$TaxaClass == "Catadromous")]), lwd=2)

plot(fdat$Year[which(fdat$Taxa == "Mammalia")],fdat$Ho[which(fdat$Taxa == "Mammalia")], xlab="Year",main="",
     col="orange", xlim = c(1990,2017), ylim = c(0,1), cex.axis=2, cex.lab=2, cex.main=2, ylab="Mammals", pch=19, cex=1.5)
abline(lm(fdat$Ho[which(fdat$Taxa == "Mammalia")]~fdat$Year[which(fdat$Taxa == "Mammalia")]), lwd=2)
plot(fdat$Year[which(fdat$Taxa == "Mammalia")],fdat$MNA[which(fdat$Taxa == "Mammalia")], xlab="Year",main="", pch=19,
     col="orange", xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, ylab="", cex=1.5)
abline(lm(fdat$MNA[which(fdat$Taxa == "Mammalia")]~fdat$Year[which(fdat$Taxa == "Mammalia")]), lwd=2)
plot(fdat$Year[which(fdat$Taxa == "Mammalia")],fdat$Msats[which(fdat$Taxa == "Mammalia")], xlab="Year",main="", pch=19,
     col="orange", xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, ylab="", cex=1.5)
abline(lm(fdat$MNA[which(fdat$Taxa == "Mammalia")]~fdat$Year[which(fdat$Taxa == "Mammalia")]), lwd=2)

plot(fdat$Year[which(fdat$TaxaClass == "Reptilia")],fdat$Ho[which(fdat$TaxaClass == "Reptilia")],xlab="Year",main="",
     col="olivedrab3", xlim = c(1990,2017), ylim = c(0,1), cex.axis=2, cex.lab=2, cex.main=2, ylab="Reptilia", pch=19, cex=1.5)
abline(lm(fdat$Ho[which(fdat$TaxaClass == "Reptilia")]~fdat$Year[which(fdat$TaxaClass == "Reptilia")]), lwd=2)
plot(fdat$Year[which(fdat$TaxaClass == "Reptilia")],fdat$MNA[which(fdat$TaxaClass == "Reptilia")],xlab="Year",main="", pch=19,
     col="olivedrab3", xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, ylab="", cex=1.5)
abline(lm(fdat$MNA[which(fdat$Taxa == "Reptilia")]~fdat$Year[which(fdat$Taxa == "Reptilia")]), lwd=2)
plot(fdat$Year[which(fdat$TaxaClass == "Reptilia")],fdat$Msats[which(fdat$TaxaClass == "Reptilia")],xlab="Year",main="", pch=19,
     col="olivedrab3", xlim = c(1990,2017), cex.axis=2, cex.lab=2, cex.main=2, ylab="", cex=1.5)
abline(lm(fdat$MNA[which(fdat$TaxaClass == "Reptilia")]~fdat$Year[which(fdat$TaxaClass == "Reptilia")]), lwd=2)

########## Figure 4 ########## 
fdat<-read.csv("MacroPopGen_Database_final.csv")
par(mfrow=c(1,2))
plot(fdat$Ho, fdat$Msats, main="Ho", col="darkolivegreen4", xlab="", ylab="Number of Microsatellite Loci",
     cex.axis=2, cex.lab=2, cex.main=2,  cex=1.5)
abline(v=0.5929, lwd=3) #avg Ho is 0.62
plot(log(fdat$MNA), fdat$Msats,main="Log MNA", col="dodgerblue4", xlab="", ylab="",
     cex.axis=2, cex.lab=2, cex.main=2,  cex=1.5)
abline(v=2.06986, lwd=3)#avg MNA is 7.923713 so log that

#I do not have variance so cannot do a formal test e.g. Egger's
#Instead will do a simple linear regression
summary(lm(Ho ~ Msats, data=fdat))  #p=0.000674, estimate=0.0013359, adjust R2=0.001664
summary(lm(MNA ~ Msats, data=fdat)) #p<2e-16, estimate=0.17235, adjust R2=0.02694


########## Ascertainment Bias: Ho ##########
mammal <- read.csv(file = "Mammal_Subset_AscertainmentBias.csv")
library(glmmTMB)

model0 <- glmmTMB(Ho ~ 1+
                          (1|RefID) + (1|Species) + (1|Genus) + (1|Family),
                  family=beta_family(), data = mammal)
model0.1 <- glmmTMB(Ho ~ 1+
                            (1|Species) + (1|Genus) + (1|Family),
                    family=beta_family(), data = mammal)
model0.2 <- glmmTMB(Ho ~ 1+
                            (1|RefID) +  (1|Genus) + (1|Family),
                    family=beta_family(), data = mammal)
model0.3 <- glmmTMB(Ho ~ 1+
                            (1|RefID) + (1|Species) + (1|Genus),
                    family=beta_family(), data = mammal)

anova(model0, model0.1, model0.2,  model0.3)
#We removed species as a random effect because the variance explained was much 
#smaller than RefID, Genus and Family

mammal$nh = mammal$NSpp
mammal$mth=mammal$MsatType
mammal$mh=mammal$msat
mammal$hh=mammal$Harvested
mammal$cch=mammal$ConservC
mammal$eh=mammal$Economic
mammal$ch=mammal$Charisma
mammal$ach=mammal$AuthorCountry

m1 <- glmmTMB(Ho ~ NSpp +
                      (1|RefID) + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m2 <- glmmTMB(Ho ~ Msats + 
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)


m3 <- glmmTMB(Ho ~ MsatType + 
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m4 <- glmmTMB(Ho ~ Harvested + 
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m5 <- glmmTMB(Ho ~ ConservC + 
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m6 <- glmmTMB(Ho ~ Economic + 
                      (1|RefID) + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m7 <- glmmTMB(Ho ~ Charisma + 
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m8 <- glmmTMB(Ho ~ AuthorCountry +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)
anova(m1,m2,m3,m4,m5,m6,m7,m8)
#m5 - conservC

m1 <- glmmTMB(Ho ~ NSpp +ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m2 <- glmmTMB(Ho ~ Msats + ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)


m3 <- glmmTMB(Ho ~ MsatType + ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m4 <- glmmTMB(Ho ~ Harvested + ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m5 <- glmmTMB(Ho ~  ConservC + 
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m6 <- glmmTMB(Ho ~ Economic + ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m7 <- glmmTMB(Ho ~ Charisma + ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m8 <- glmmTMB(Ho ~ AuthorCountry + ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

anova(m1,m2,m3,m4,m5,m6,m7,m8)
#m4 selected

m4 <- glmmTMB(Ho ~ Harvested + ConservC + 
                      (1|RefID) + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m4.i <- glmmTMB(Ho ~ Harvested * ConservC +
                        (1|RefID)  + (1|Genus) + (1|Family),
                family=beta_family(), data = mammal)

anova(m4, m4.i) #interaction selected


m1 <- glmmTMB(Ho ~ NSpp +Harvested * ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m2 <- glmmTMB(Ho ~ Msats + Harvested * ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)


m3 <- glmmTMB(Ho ~ MsatType + Harvested * ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m4 <- glmmTMB(Ho ~  Harvested * ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m6 <- glmmTMB(Ho ~ Economic + Harvested * ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m7 <- glmmTMB(Ho ~ Charisma + Harvested * ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

m8 <- glmmTMB(Ho ~ AuthorCountry +Harvested * ConservC +
                      (1|RefID)  + (1|Genus) + (1|Family),
              family=beta_family(), data = mammal)

anova(m1,m2,m3,m4,m6,m7,m8)
#selected model is m4


#m4 is the best model


library(DHARMa)
res = simulateResiduals(m4)
plot(res, rank = T)


########## Ascertainment Bias: MNA ##########
amam <- read.csv("Mammal_Subset_AscertainmentBias.csv")
mnamam <- amam[!(is.na(amam$MNA)),]

library(lme4)
mnamam$rmn <- factor(mnamam$Relatedness, levels=c("Class", "Order", "Family", "Genus", "Species"))
mnamam$nmn <- scale(mnamam$NSpp, scale=T, center = T)
mnamam$mmn <- scale(mnamam$Msats, scale=T, center=T)
mnamam$mtmn <- factor(mnamam$MsatType, levels=c("Nonnative", "Mixed", "Native"))
mnamam$hmn <- factor(mnamam$Harvested, levels=c("No", "Low", "High"))
mnamam$ccmn <- factor(mnamam$ConservC, levels=c("No", "Low", "High"))
mnamam$emn <- factor(mnamam$Economic, levels=c("No", "Low", "High"))
mnamam$cmn <- factor(mnamam$Charisma, levels=c("No", "Low", "High"))
mnamam$acmn <- factor(mnamam$AuthorCountry, levels=c("USA", "Canada", "Mexico", "UK", "Russia", "Norway",
                                                     "Spain", "Swedan"))

#step 1: find  random effect structure
Mm00 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                      nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                      (1|RefID) + (1|Species) + (1|Genus) + (1|Family),
              data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma(link = "inverse"))
#Convergence issues: https://rstudio-pubs-static.s3.amazonaws.com/33653_57fc7b8e5d484c909b615d8633c01d51.html
#try rescaling
nrow(mnamam) #1134
length(getME(Mm00,"theta")) #4
length(fixef(Mm00))#32

numcols <- grep("^c\\.",names(mnamam))
dfs <- mnamam
dfs[,numcols] <- scale(dfs[,numcols])
m1_sc <- update(Mm00,data=dfs)
tt <- getME(m1_sc,"theta")
ll <- getME(m1_sc,"lower")
#test for singularity: if parameters are =0 or very very close to zero, say <10−6 then issue
min(tt[ll==0]) #0.00112823;  not an issue
#extract gradient calculation
derivs1 <- m1_sc@optinfo$derivs
sc_grad1 <- with(derivs1,solve(Hessian,gradient))
max(abs(sc_grad1)) #0.01780768
max(pmin(abs(sc_grad1),abs(derivs1$gradient))) #0.01780768 #same value
#try more accurate calc
require(numDeriv)
dd <- update(m1_sc,devFunOnly=TRUE)
pars <- unlist(getME(m1_sc,c("theta","fixef")))
grad2 <- grad(dd,pars)
hess2 <- hessian(dd,pars)
sc_grad2 <- solve(hess2,grad2)
max(pmin(abs(sc_grad2),abs(grad2))) #0.05974927
#try restarting to increase number of iterations
ss <- getME(m1_sc,c("theta","fixef"))
m2 <- update(m1_sc,start=ss,control=glmerControl(optCtrl=list(maxfun=2e5)))
#still convergence issues
m3 <- update(m1_sc,start=ss,control=glmerControl(optimizer="bobyqa",
                                                 optCtrl=list(maxfun=2e5)))
#still not converging but difference between parameters is minimal so will go on with model selection!
Mm01 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                      nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                      (1|RefID) + (1|Species) + (1|Genus),
              data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm02 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                      nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                      (1|RefID) + (1|Species)+ (1|Family),
              data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm03 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                      nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                      (1|RefID) + (1|Genus) + (1|Family),
              data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm04 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                      nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                      (1|Species) + (1|Genus) + (1|Family),
              data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm00, Mm01) #p=1
anova(Mm00, Mm02) #p=0.6461
anova(Mm00, Mm03) #p=1
anova(Mm00, Mm04) #p< 2.2e-16
min(anova(Mm00,Mm01, Mm02,Mm03, Mm04)$AIC) #4043.68
#M01 is the best model (Family removed)

Mm01 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                      nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                      (1|RefID) + (1|Species) + (1|Genus),
              data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm011 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                       nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                       (1|RefID) + (1|Species),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                       nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                       (1|RefID) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm013 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                       nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                       (1|Species) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm01, Mm011) #p=0.02152
anova(Mm01, Mm012) #p=0.01604
anova(Mm01, Mm013) #p=< 2.2e-16
anova(Mm01,Mm011,Mm012,Mm013)
#M01 best remove no more fixed effects

#Look for which interactions are significant
Mm012 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                       nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                       (1|RefID) + (1|Species) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012a <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                        nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + 
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012b <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                        nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:ccmn + ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                        nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:cmn + ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012d <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                        nmn:mmn + nmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012e <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                        nmn:mmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012f <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                        nmn:mtmn + mmn:mtmn + hmn:ccmn + hmn:cmn + ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm012, Mm012a) #p=0.00253
anova(Mm012, Mm012b) #p=0.2848
anova(Mm012, Mm012c) #p=0.8266
anova(Mm012, Mm012d) #p=0.1591
anova(Mm012, Mm012e) #p=0.2051
anova(Mm012, Mm012f) #p=0.7214
anova(Mm012,Mm012a,Mm012b,Mm012c,Mm012d,Mm012e,Mm012f)
#Mm012c is best with hmn:ccmn  (harvest: conserv c) removed

Mm012c <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                        nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:cmn + ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c1 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                         nmn:mmn + nmn:mtmn + mmn:mtmn + hmn:cmn + 
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c2 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                         nmn:mmn + nmn:mtmn + mmn:mtmn + ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c3 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                         nmn:mmn + nmn:mtmn + hmn:cmn + ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c4 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                         nmn:mmn + mmn:mtmn + hmn:cmn + ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c5 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                         nmn:mtmn + mmn:mtmn + hmn:cmn + ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm012c, Mm012c1) #p=0.001961
anova(Mm012c, Mm012c2) #p=0.3165
anova(Mm012c, Mm012c3) #p=0.2546
anova(Mm012c, Mm012c4) #p=0.1906
anova(Mm012c, Mm012c5) #p=0.7636
anova(Mm012c, Mm012c1,Mm012c2,Mm012c3,Mm012c4,Mm012c5)
#Mm012c2 is best with hmn:cmn (harvest : charisma) removed

Mm012c2 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                         nmn:mmn + nmn:mtmn + mmn:mtmn + ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c21 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                          nmn:mmn + nmn:mtmn + mmn:mtmn + 
                          (1|RefID) + (1|Species) + (1|Genus),
                  data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c22 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                          nmn:mmn + nmn:mtmn + ccmn:cmn +
                          (1|RefID) + (1|Species) + (1|Genus),
                  data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c23 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                          nmn:mmn + mmn:mtmn + ccmn:cmn +
                          (1|RefID) + (1|Species) + (1|Genus),
                  data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c24 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                          nmn:mtmn + mmn:mtmn + ccmn:cmn +
                          (1|RefID) + (1|Species) + (1|Genus),
                  data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm012c2, Mm012c21) #p=0.001732
anova(Mm012c2, Mm012c22) #p=0.2492
anova(Mm012c2, Mm012c23) #p=0.2959
anova(Mm012c2, Mm012c24) #p=1
anova(Mm012c2, Mm012c21,Mm012c22,Mm012c23,Mm012c24)
#Mm012c24 is best with nmn:mmn (#spp:msat ) removed

Mm012c24 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                          nmn:mtmn + mmn:mtmn + ccmn:cmn +
                          (1|RefID) + (1|Species) + (1|Genus),
                  data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c241 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                           nmn:mtmn + mmn:mtmn + 
                           (1|RefID) + (1|Species) + (1|Genus),
                   data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c242 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                           nmn:mtmn + ccmn:cmn +
                           (1|RefID) + (1|Species) + (1|Genus),
                   data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c243 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                           mmn:mtmn + ccmn:cmn +
                           (1|RefID) + (1|Species) + (1|Genus),
                   data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm012c24, Mm012c241) #p=0.00158
anova(Mm012c24, Mm012c242) #p=0.2167
anova(Mm012c24, Mm012c243) #p=0.2388
anova(Mm012c24, Mm012c241, Mm012c242, Mm012c243)
#Mm012c243 is best model with nmn:mtmn (#spp :msat type) removed

Mm012c243 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                           mmn:mtmn + ccmn:cmn +
                           (1|RefID) + (1|Species) + (1|Genus),
                   data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c2431 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                            mmn:mtmn + 
                            (1|RefID) + (1|Species) + (1|Genus),
                    data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c2432 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                            ccmn:cmn +
                            (1|RefID) + (1|Species) + (1|Genus),
                    data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm012c243, Mm012c2431) #p=0.001511
anova(Mm012c243, Mm012c2432) #p=0.1764
anova(Mm012c243, Mm012c2431, Mm012c2432) #Mm012c2432
#Mm012c2432 best model with nmn:mmn (#spp : #msats removed

Mm012c2432 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                            ccmn:cmn +
                            (1|RefID) + (1|Species) + (1|Genus),
                    data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm012c2432N <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                             (1|RefID) + (1|Species) + (1|Genus),
                     data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm012c2432, Mm012c2432N) #p=0.005995
#Mm012c2432 is best model


#step 3: Finding  fixed effect structure
Mm1 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                     ccmn:cmn +
                     (1|RefID) + (1|Species) + (1|Genus),
             data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.1 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + cmn +   
                       ccmn:cmn +
                       (1|RefID) + (1|Species) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.2 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + emn + acmn +  
                       ccmn:cmn +
                       (1|RefID) + (1|Species) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.3 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + cmn + acmn +  
                       ccmn:cmn +
                       (1|RefID) + (1|Species) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.4 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + emn + cmn + acmn +  
                       ccmn:cmn +
                       (1|RefID) + (1|Species) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.5 <- glmer(MNA ~ nmn + mmn + mtmn + ccmn + emn + cmn + acmn +  
                       ccmn:cmn +
                       (1|RefID) + (1|Species) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.6 <- glmer(MNA ~ nmn + mmn + hmn + ccmn + emn + cmn + acmn +  
                       ccmn:cmn +
                       (1|RefID) + (1|Species) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.7 <- glmer(MNA ~ nmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                       ccmn:cmn +
                       (1|RefID) + (1|Species) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.8 <- glmer(MNA ~ mmn + mtmn + hmn + ccmn + emn + cmn + acmn +  
                       ccmn:cmn +
                       (1|RefID) + (1|Species) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm1, Mm1.1) #p=0.4152
anova(Mm1, Mm1.2) #p=< 2.2e-16
anova(Mm1, Mm1.3) #p=0.9707
anova(Mm1, Mm1.4) #p=< 2.2e-16
anova(Mm1, Mm1.5) #p=0.83
anova(Mm1, Mm1.6) #p=0.5185
anova(Mm1, Mm1.7) #p=0.4168
anova(Mm1, Mm1.8) #p=0.1162
anova(Mm1, Mm1.1, Mm1.2,Mm1.3,Mm1.4,Mm1.5,Mm1.6,Mm1.7,Mm1.8)
#Mm1.3 is best model with emn (economic) removed


Mm1.3 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + cmn + acmn +  
                       ccmn:cmn +
                       (1|RefID) + (1|Species) + (1|Genus),
               data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.31 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + cmn +  
                        ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.32 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + ccmn + acmn +  
                        ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.33 <- glmer(MNA ~ nmn + mmn + mtmn + hmn + cmn + acmn +  
                        ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.34 <- glmer(MNA ~ nmn + mmn + mtmn + ccmn + cmn + acmn +  
                        ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.35 <- glmer(MNA ~ nmn + mmn + hmn + ccmn + cmn + acmn +  
                        ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.36 <- glmer(MNA ~ nmn + mtmn + hmn + ccmn + cmn + acmn +  
                        ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.37 <- glmer(MNA ~ mmn + mtmn + hmn + ccmn + cmn + acmn +  
                        ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm1.3, Mm1.31) #p=0.3733
anova(Mm1.3, Mm1.32) #p=< 2.2e-16
anova(Mm1.3, Mm1.33) #p=1
anova(Mm1.3, Mm1.34) #p=0.7068
anova(Mm1.3, Mm1.35) #p=0.5151
anova(Mm1.3, Mm1.36) #p=0.3361
anova(Mm1.3, Mm1.37) #p=0.1115
anova(Mm1.3,Mm1.31,Mm1.32,Mm1.33,Mm1.34,Mm1.35,Mm1.36,Mm1.37)
#Mm1.34 is best model with hmn (harvest) removed

Mm1.34 <- glmer(MNA ~ nmn + mmn + mtmn + ccmn + cmn + acmn +  
                        ccmn:cmn +
                        (1|RefID) + (1|Species) + (1|Genus),
                data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.341 <- glmer(MNA ~ nmn + mmn + mtmn + ccmn + cmn +  
                         ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.342 <- glmer(MNA ~ nmn + mmn + mtmn + ccmn + acmn +  
                         ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.343 <- glmer(MNA ~ nmn + mmn + mtmn + cmn + acmn +  
                         ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.344 <- glmer(MNA ~ nmn + mmn + ccmn + cmn + acmn +  
                         ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.345 <- glmer(MNA ~ nmn + mtmn + ccmn + cmn + acmn +  
                         ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.346 <- glmer(MNA ~ mmn + mtmn + ccmn + cmn + acmn +  
                         ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm1.34, Mm1.341) #p=0.2394
anova(Mm1.34, Mm1.342) #p=1
anova(Mm1.34, Mm1.343) #p=1
anova(Mm1.34, Mm1.344) #p=0.5206; AIC lowest
anova(Mm1.34, Mm1.345) #p=0.3671
anova(Mm1.34, Mm1.346) #p=0.1466
anova(Mm1.34, Mm1.341, Mm1.342,Mm1.343,Mm1.344,Mm1.345,Mm1.346)
#Mm1.342 is best with cmn removed

Mm1.342 <- glmer(MNA ~ nmn + mmn + mtmn + ccmn + acmn +  
                         ccmn:cmn +
                         (1|RefID) + (1|Species) + (1|Genus),
                 data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.3421 <- glmer(MNA ~ nmn + mmn + mtmn + ccmn +  
                          ccmn:cmn +
                          (1|RefID) + (1|Species) + (1|Genus),
                  data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.3422 <- glmer(MNA ~ nmn + mmn + mtmn + acmn +  
                          ccmn:cmn +
                          (1|RefID) + (1|Species) + (1|Genus),
                  data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.3423 <- glmer(MNA ~ nmn + mmn + ccmn + acmn +  
                          ccmn:cmn +
                          (1|RefID) + (1|Species) + (1|Genus),
                  data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.3424 <- glmer(MNA ~ nmn + mtmn + ccmn + acmn +  
                          ccmn:cmn +
                          (1|RefID) + (1|Species) + (1|Genus),
                  data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.3425 <- glmer(MNA ~ mmn + mtmn + ccmn + acmn +  
                          ccmn:cmn +
                          (1|RefID) + (1|Species) + (1|Genus),
                  data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm1.342, Mm1.3421) #p=0.2564
anova(Mm1.342, Mm1.3422) #p< 2.2e-16
anova(Mm1.342, Mm1.3423) #p=0.542
anova(Mm1.342, Mm1.3424) #p=0.3695
anova(Mm1.342, Mm1.3425) #p=0.1581
anova(Mm1.342, Mm1.3421,Mm1.3422,Mm1.3423,Mm1.3424,Mm1.3425)
#Mm1.3423 is best model with mtmn (msat type) removed

Mm1.3423 <- glmer(MNA ~ nmn + mmn + ccmn + acmn +  
                          ccmn:cmn +
                          (1|RefID) + (1|Species) + (1|Genus),
                  data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.34231 <- glmer(MNA ~ nmn + mmn + ccmn +   
                           ccmn:cmn +
                           (1|RefID) + (1|Species) + (1|Genus),
                   data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.34232 <- glmer(MNA ~ nmn + mmn + acmn +  
                           ccmn:cmn +
                           (1|RefID) + (1|Species) + (1|Genus),
                   data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.34233 <- glmer(MNA ~ nmn + ccmn + acmn +  
                           ccmn:cmn +
                           (1|RefID) + (1|Species) + (1|Genus),
                   data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.34234 <- glmer(MNA ~ mmn + ccmn + acmn +  
                           ccmn:cmn +
                           (1|RefID) + (1|Species) + (1|Genus),
                   data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm1.3423, Mm1.34231) #p=0.3398
anova(Mm1.3423, Mm1.34232) #p< 2.2e-16
anova(Mm1.3423, Mm1.34233) #p=0.6172
anova(Mm1.3423, Mm1.34234) #p=0.357
anova(Mm1.3423,Mm1.34231,Mm1.34232,Mm1.34233,Mm1.34234)
#Mm1.34233 is best model with mmn (msat) removed

Mm1.34233 <- glmer(MNA ~ nmn + ccmn + acmn +  
                           ccmn:cmn +
                           (1|RefID) + (1|Species) + (1|Genus),
                   data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.342331 <- glmer(MNA ~ nmn + ccmn +  
                            ccmn:cmn +
                            (1|RefID) + (1|Species) + (1|Genus),
                    data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.342332 <- glmer(MNA ~ nmn + acmn +  
                            ccmn:cmn +
                            (1|RefID) + (1|Species) + (1|Genus),
                    data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.342333 <- glmer(MNA ~ ccmn + acmn +  
                            ccmn:cmn +
                            (1|RefID) + (1|Species) + (1|Genus),
                    data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm1.34233, Mm1.342331) #p=0.3749
anova(Mm1.34233, Mm1.342332) #p=1
anova(Mm1.34233, Mm1.342333) #p=0.3542
anova(Mm1.34233, Mm1.342331,Mm1.342332,Mm1.342333)
#Mm1.342332 is best model with ccmn (conserv conc) removed

Mm1.342332 <- glmer(MNA ~ nmn + acmn +  
                            ccmn:cmn +
                            (1|RefID) + (1|Species) + (1|Genus),
                    data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.3423321 <- glmer(MNA ~ nmn +   
                             ccmn:cmn +
                             (1|RefID) + (1|Species) + (1|Genus),
                     data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.3423322 <- glmer(MNA ~ acmn +  
                             ccmn:cmn +
                             (1|RefID) + (1|Species) + (1|Genus),
                     data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm1.342332, Mm1.3423321) #p=0.37
anova(Mm1.342332, Mm1.3423322) #p=0.3549
anova(Mm1.342332, Mm1.3423321, Mm1.3423322)
#remove Mm1.3423321 (acmn)

Mm1.3423321 <- glmer(MNA ~ nmn +   
                             ccmn:cmn +
                             (1|RefID) + (1|Species) + (1|Genus),
                     data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
Mm1.3423321N <- glmer(MNA ~ ccmn:cmn +
                              (1|RefID) + (1|Species) + (1|Genus),
                      data=mnamam, control = glmerControl(optimizer = "Nelder_Mead"), family=Gamma)
anova(Mm1.3423321, Mm1.3423321N) #p=0.2274
#remove all fixed effects

########## Distance ##########
library(geosphere)
data <- read.csv("Populations_Distances.csv")
fdat <- read.csv("MacroPopGen_Database_final.csv")
data$Min.Distance <- NA
data$Max.Distance <- NA
data$Mean.Distance <- NA
data$N.Population <- NA
ref.vector <- unique(data$RefID)


for(x in 1:length(ref.vector)){
        
        temp.data <- data[which(data$RefID == ref.vector[x]),]
        n <- nrow(temp.data)
        
        dist.matrix <- distm(as.matrix(data.frame(temp.data$Long[1:n],temp.data$Lat[1:n])), as.matrix(data.frame(temp.data$Long[1:n],temp.data$Lat[1:n])), fun = distHaversine)
        #Applying the minimum distance (other than 0, which is the distance to itself) to the data rows of the given reference
        data$Min.Distance[which(data$RefID == ref.vector[x])] <- apply(dist.matrix, 1, FUN = function(x) {min(x[x > 0])})
        #Applying the maximum distance to the data rows of the given reference
        data$Max.Distance[which(data$RefID == ref.vector[x])] <- apply(dist.matrix, 1, FUN = max)
        #Applying the average distance (other than 0, which is the distance to itself) to the data rows of the given reference
        data$Mean.Distance[which(data$RefID == ref.vector[x])] <- apply(dist.matrix, 1, FUN = function(x) {mean(x[x > 0])})
        #Calculating the number of pops per study
        data$N.Population[which(data$RefID == ref.vector[x])] <- n
}


#The original database had certain populations combined, which is problematic for calculating distances,
#so we are re-assembling the database after having seperated certain populations manually beforehand

#Re-adding Ho, He, MNA, & AR to the database

data$Ho <- NA
data$He <- NA
data$MNA <- NA
data$AR <- NA
pop.vector <- unique(data$PopId)

for(x in 1:length(pop.vector)){
        if(nrow(fdat[which(fdat$PopId == pop.vector[x]),]) > 0){
                data$Ho[which(data$PopId == pop.vector[x])] <- fdat$Ho[which(fdat$PopId == pop.vector[x])]
                data$He[which(data$PopId == pop.vector[x])] <- fdat$He[which(fdat$PopId == pop.vector[x])]
                data$MNA[which(data$PopId == pop.vector[x])] <- fdat$MNA[which(fdat$PopId == pop.vector[x])]
                data$AR[which(data$PopId == pop.vector[x])] <- fdat$AR[which(fdat$PopId == pop.vector[x])]
        }
}

write.csv(data, "MacroPopGen_Database_final_allpops.csv")