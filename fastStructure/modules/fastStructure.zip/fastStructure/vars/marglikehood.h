
typedef unsigned char uint8_t;

double marglikehood( const uint8_t* G, const double* zetabeta, const double* zetagamma, const double* xi, long N, long L, long K );
