typedef unsigned char uint8_t;

void Q_update( const uint8_t* G, const double* zetabeta, const double* zetagamma, const double* xi, double* new_var, long N, long L, long K );
