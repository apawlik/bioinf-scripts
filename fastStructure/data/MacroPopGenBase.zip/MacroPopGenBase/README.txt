This dataset and R script come from 
Lawrence, E. R. et al. MacroPopGen Database: Geo-referenced population-specific microsatellite data across the American continents. figshare https://doi.org/10.6084/m9.figshare.7207514.v1 (2018).

Files associated with the MacroPopGenBase:

1) .XLSX file documenting references for associated reference IDs, and list of key terms used in meta-analytical searches.
2) .XLSX with MacroPopGenBase data [24 columns, 9090 rows] as well as data file documenting all localities and distances between them [26 columns, 10921 rows]. Associated Read Me tabs also included.
3) .CSV file with subset of North American mammal data used for testing ascertainment bias associated with mirosatellite loci.
4) All R code used to produce figures and analyses presented in Lawrence et al. (in revision) Scientific Data